let searchInputELE = document.getElementById("searchInput");
let searchResultsELE = document.getElementById("searchResults");
let spinnerELE = document.getElementById("spinner");
let resultEle = document.createElement("div");
resultEle.classList.add("result-item");

function CreateAndAppend(data) {
    let head = document.createElement("a");
    head.textContent = data.title;
    head.target = "_blank";
    head.classList.add("result-title");
    resultEle.appendChild(head);
    let breaker = document.createElement("br");
    resultEle.appendChild(breaker);
    let head1 = document.createElement("a");
    head1.textContent = data.link;
    head1.target = "_blank";
    head1.classList.add("result-url");
    resultEle.appendChild(head1);
    let para = document.createElement("p");
    para.textContent = data.description;
    para.target = "_blank";
    para.classList.add("link-description");
    resultEle.appendChild(para);
    searchResultsELE.appendChild(resultEle);
}

function sendGetHTTPRequest(event) {
    if (event.key === "Enter" && event.target.value !== "") {
        searchResultsELE.textContent = "";
        let requestUrl = "https://apis.ccbp.in/wiki-search?search=" + event.target.value;
        let options = {
            method: "GET"
        };
        spinnerELE.classList.remove("d-none");
        fetch(requestUrl, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                spinnerELE.classList.add("d-none");
                for (let each of jsonData.search_results) {
                    CreateAndAppend(each);
                }
            });
    }
}
searchInputELE.addEventListener("keydown", sendGetHTTPRequest);